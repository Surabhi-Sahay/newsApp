export const BASE_API_URL = 'https://hacker-news.firebaseio.com/v0';
